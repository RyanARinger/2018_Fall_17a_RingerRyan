/* 
 * File:   BattleShip.h
 * Author: Ryan Ringer
 * 
 * Purpose: 
 */

#ifndef BATTLESHIP_H
#define BATTLESHIP_H

#include "shipClass.h"
using namespace std;

#include <string>

class BatShip : public Ship{
    private:
	
    public:
	friend class Game;
	
	// constructor
	BatShip();
	
	// destructor
	
	// setter for the ship name 
	void setName(string n) { name = n; }
	
	// setter for size and hits
	void setSize(int);
	
	// setter for coordinates
	void setCord(int,int);
	
	// setter for vertical tester boolean
	void setVert(int);
	
	// getter for size and hits
	int getSize() const { return this->size; }
	
	// getter for remaining hits
	int getHits() const { return this->hits; }
	
	// getter for name
	string getName() const { return this->name; }
	
	// getter for vert
	bool getVert() const { return vert; }
	
	// getter for coordinates
	int getCord(bool) const;
	
	// overloaded -- operator
	BatShip operator--(int);
	
	// print function
	void prnShip();
	
};


#endif /* BATTLESHIP_H */

