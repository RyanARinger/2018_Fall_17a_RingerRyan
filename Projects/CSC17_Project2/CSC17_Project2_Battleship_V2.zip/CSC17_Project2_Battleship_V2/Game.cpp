/* 
 * File:   Game.cpp
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#include <iostream>
using namespace std;

#include "Game.h"

Game::Game(){
    
    this->setBrd();
    this->dispBrd();
    this->PrnShips();
    
    
}
Game::~Game(){
    const int SIDE = 10;
    
    for(int i = 0; i<SIDE; i++){
	
	delete[] this->board[i];
    }
}
void Game::setBrd(){
    this->board = new Coord*[10];
    for(int i = 0; i<10; i++){
	this->board[i] = new Coord[10];
    }
}
void Game::dispBrd(){
    for(int i=0; i<10;i++){
	for(int j=0; j<10; j++){
	    if(this->board[i][j].getCal()){
		if(this->board[i][j].getCal()){
		    cout << "2 ";
		}
		else{
		    cout << "1 ";
		}
	    }
	    else{
		cout << "0 ";
	    }
	}
	cout << endl;
    }
   
}

int Game::fndVert(){
    int result = rand()%2;
    return result;
}

int Game::cordFnd(){
    int cord = rand()%10;
    return cord;
}

void Game::setShps(){
    bool set;
    // carrier vertcal
    try{
	carrier.setVert(this->fndVert());
    }
    catch(string message){
	cout << message;
	this->setShps();
    }
    
    // battleship vertical
    try{
	battle.setVert(this->fndVert());
    }
    catch(string message){
	cout << message;
	this->setShps();
    }
    
    // destroyer  vertical
    try{
	des.setVert(this->fndVert());
    }
    catch(string message){
	cout << message;
	this->setShps();
    }
    
    // submarine vertical
    try{
	sub.setVert(this->fndVert());
    }
    catch(string message){
	cout << message;
	this->setShps();
    }
    
    // patrol boat vertical
    try{
	patrol.setVert(this->fndVert());
    }
    catch(string message){
	cout << message;
	this->setShps();
    }
    
    // carrier coordinate
    do{
	set = true;
	
	try{
	    this->carrier.setCord(this->cordFnd(), this->cordFnd());
	}
	catch(bool test){
	    set = test;
	}
    }while(!set);
    
    // battleship coordinate
    do{
	set = true;
	
	try{
	    this->battle.setCord(this->cordFnd(), this->cordFnd());
	}
	catch(bool test){
	    set = test;
	}
    }while(!set);
    
    // destroyer coordinate
    do{
	set = true;
	
	try{
	    this->des.setCord(this->cordFnd(), this->cordFnd());
	}
	catch(bool test){
	    set = test;
	}
    }while(!set);
    
    // submarine coordinate
    do{
	set = true;
	
	try{
	    this->sub.setCord(this->cordFnd(), this->cordFnd());
	}
	catch(bool test){
	    set = test;
	}
    }while(!set);
    
    // patrol boat coordinate
    do{
	set = true;
	
	try{
	    this->patrol.setCord(this->cordFnd(), this->cordFnd());
	}
	catch(bool test){
	    set = test;
	}
    }while(!set);
}

void Game::PrnShips(){
    battle.prnShip();
    carrier.prnShip();
    des.prnShip();
    sub.prnShip();
    patrol.prnShip();
}