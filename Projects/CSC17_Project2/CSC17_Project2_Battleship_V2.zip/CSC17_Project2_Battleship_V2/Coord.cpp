/* 
 * File:   Coord.cpp
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#include "Coord.h"

Coord::Coord(){
    this->setCal();
    this->setMod();
}