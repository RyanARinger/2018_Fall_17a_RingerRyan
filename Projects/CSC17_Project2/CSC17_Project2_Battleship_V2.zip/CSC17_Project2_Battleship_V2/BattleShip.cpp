/* 
 * File:   BattleShip.cpp
 * Author: Ryan Ringer
 * Created on December 12, 2018 4:26 PM
 * Purpose: 
 */
#include <string>
#include <iostream>
#include <cstdlib>
using namespace std;

#include "BattleShip.h"


BatShip::BatShip(){
    int hitPnts = 4;
    string nm = "Battleship";
    this->setName(nm);
    this->setSize(hitPnts);
//    this->prnShip();
}

void BatShip::setSize(int s){
    
    // this function only needs one variable passed because 
    // the size and number of hit points are identical
    
    this->size = s;
    this->hits = s;
}

void BatShip::setVert(int v){
    if(v == 0){
	// if random number % 2 results in zero
	// then set vert to false
	
	this->vert = false;
    }
    else if(v == 1){
	// if random number % 2 results in one
	// then set vert to true
	
	this->vert = true;
    }
    else{
	string error = "Error: random number out of bounds";
	throw error;
    }
    
}

void BatShip::setCord(int x, int y){
    
    if(this->vert){
	if(10-x >= this->size){
	    this->xCrd = x;
	    this->yCrd = y;
	}
	else{
	    bool test = false;
	    throw test;
	}
    }
    else if(!this->vert){
	if(10-y >= size){
	    this->xCrd = x;
	    this->yCrd = y;
	}
	else{
	    bool test = false;
	    throw test;
	}
    }
}

void BatShip::prnShip(){
    cout << this->name << endl;
    cout << this->size << endl;
    cout << this->hits << endl;
    cout << "(" << this->xCrd << ", " << this->yCrd << ")" << endl;
}

BatShip BatShip::operator --(int){
    this->hits = this->hits - 1;
    return *this;
}

int BatShip::getCord(bool xy) const{
    
    if(xy){
	return this->yCrd;
    }
    else{
	return this->xCrd;
    }
}