/* 
 * File:   Carrier.h
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#ifndef CARRIER_H
#define CARRIER_H
#include <string>
using namespace std;


#include "shipClass.h"

class Carrier : public Ship{
    private:
	
    public:
	friend class Game;
	
	// constructor
	Carrier();
	
	// setter for the ship name 
	void setName(string n) { name = n; }
	
	// setter for size and hits
	void setSize(int);
	
	// setter for coordinates
	void setCord(int,int);
	
	// setter for vertical tester boolean
	void setVert(int);
	
	// getter for size and hits
	int getSize() const { return this->size; }
	
	// getter for remaining hits
	int getHits() const { return this->hits; }
	
	// getter for name
	string getName() const { return this->name; }
	
	// getter for vert
	bool getVert() const { return vert; }
	
	// getter for coordinates
	int getCord(bool) const;
	
	// overloaded -- operator
	Carrier operator--(int);
	
	// print function
	void prnShip();
	
};


#endif /* CARRIER_H */

