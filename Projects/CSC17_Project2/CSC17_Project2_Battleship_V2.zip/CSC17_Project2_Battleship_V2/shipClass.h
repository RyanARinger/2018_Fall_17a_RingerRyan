/* 
 * File:   shipClass.h
 * Author: Ryan Ringer
 *
 * Purpose: Base ship class definition
 */

#ifndef SHIPCLASS_H
#define SHIPCLASS_H

#include <string>
using namespace std;

class Ship{
    private:
	
	
    public:
	// constructor
	Ship();
	
	// destructor
	virtual ~Ship();
	
	// copy constructor
	Ship( Ship & );
    protected:
	
	// name
	string name;
	
	// size of the ship and hit points
	int size;
	int hits;
	
	// vertical boolean
	bool vert;
	
	// x and y head point
	int xCrd;
	int yCrd;
	
	
	
	
	
};

#endif /* SHIPCLASS_H */