/* 
 * File:   main.cpp
 * Author: Ryan Ringer
 *
 * Purpose: Programming Objects Project #2 : Battleship
 */


//System Libraries Here
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here
#include "shipClass.h"
#include "Coord.h"
#include "Game.h"
#include "BattleShip.h"

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

int getSLoc(int); // Ship location
int locTwo(); // returns a value for the second coordinate
int upDow(); // Vertical or horizontal
void cordSet(int*); //  coordinate setting


//Program Execution Begins Here

int main(int argc, char** argv) {
    // Random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Constant Variables

    //Declare all Variables Here
    Game game;
    
    game.PrnShips();
    //Input or initialize values Here
        
    //Process/Calculations Here
    
    //Output Located Here

    //Exit
    return 0;
    
}