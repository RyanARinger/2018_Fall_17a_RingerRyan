/* 
 * File:   Coord.h
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#ifndef COORD_H
#define COORD_H

class Coord{
    private:
	static int cordCnt;
	
	bool called;
	
	bool shipMod;
    
    public:
	
	Coord();
	
	void setCal() { called = false; }
	
	void setMod() { shipMod = false; }
	
//	void setCC() {cordCnt = 0; }
	
	bool getCal() const { return called; }
	
	bool getMod() const { return shipMod; }
	
	void incCal() { called = true; }
	
	void incMod() { shipMod = true; }
	
	Coord operator=(Coord);
	
};

#endif /* COORD_H */

