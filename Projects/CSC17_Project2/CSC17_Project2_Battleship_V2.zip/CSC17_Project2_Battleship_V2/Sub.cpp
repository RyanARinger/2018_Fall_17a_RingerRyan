/* 
 * File:   Sub.cpp
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

#include "Sub.h"

Sub::Sub(){
    string nm = "Submarine";
    int hitPnts = 3;
    this->setName(nm);
    this->setSize(hitPnts);
//    this->prnShip();
}

void Sub::setSize(int s){
    
    // this function only needs one variable passed because 
    // the size and number of hit points are identical
    
    this->size = s;
    this->hits = s;
}

void Sub::setVert(int v){
    if(v == 0){
	// if random number % 2 results in zero
	// then set vert to false
	
	this->vert = false;
    }
    else if(v == 1){
	// if random number % 2 results in one
	// then set vert to true
	
	this->vert = true;
    }
    else{
	string error = "Error: Random number out of bounds";
	throw error;
    }
    
}

void Sub::setCord(int x, int y){
    if(this->vert){
	if(10-x >= this->size){
	    this->xCrd = x;
	    this->yCrd = y;
	}
	else{
	    string message = "Error: X bounds overflow";
	    throw message;
	}
    }
    else if(!this->vert){
	if(10-y >= this->size){
	    this->xCrd = x;
	    this->yCrd = y;
	}
	else{
	    string message = "Error: Y bounds overflow";
	    throw message;
	}
    }
}

void Sub::prnShip(){
    cout << this->name << endl;
    cout << this->size << endl;
    cout << this->hits << endl;
}

Sub Sub::operator --(int){
    this->hits = this->hits - 1;
    return *this;
}

int Sub::getCord(bool xy) const{
    
    if(xy){
	return this->yCrd;
    }
    else{
	return this->xCrd;
    }
}