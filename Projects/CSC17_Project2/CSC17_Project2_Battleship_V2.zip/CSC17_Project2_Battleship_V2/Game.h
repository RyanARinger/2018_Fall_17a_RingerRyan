/* 
 * File:   Game.h
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <string>
using namespace std;

#include "BattleShip.h"
#include "Carrier.h"
#include "SubDes.h"
#include "Patrol.h"
#include "Sub.h"
#include "shipClass.h"
#include "Coord.h"

class Game{
    private:
	friend class Ship;
	// double pointer for dynamic 2d array for game board
	Coord ** board;
	
	// ships
	BatShip battle;
	Des des;
	Sub sub;
	Carrier carrier;
	Patrol patrol;

    public:
	// Constructor
	Game();
	
	// Destructor
	~Game();
	
	// Game setup
	void setGame();
	
	// Board setup
	void setBrd();
	
	// Board displayer
	void dispBrd();
	
	// Ship displayer
	void PrnShips();
	
	// determines verticality
	int fndVert();
	
	// finds coordinates
	int cordFnd();
	
	// ship placer
	void shpPlce(const Ship&);
	
	// Game loop
	bool play();
	
	// Ship setter
	void setShps();
	
	// Getters
	
};

#endif /* GAME_H */

