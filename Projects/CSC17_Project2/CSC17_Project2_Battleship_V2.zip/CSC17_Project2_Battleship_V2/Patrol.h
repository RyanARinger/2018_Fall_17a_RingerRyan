/* 
 * File:   Patrol.h
 * Author: Ryan Ringer
 *
 * Purpose: 
 */

#ifndef PATROL_H
#define PATROL_H

#include "shipClass.h"

class Patrol : public Ship{
    private:
	
    public:
	friend class Game;
	
	// constructor
	Patrol();
	
	// setter for the ship name 
	void setName(string n) { name = n; }
	
	// setter for size and hits
	void setSize(int);
	
	// setter for coordinates
	void setCord(int,int);
	
	// setter for vertical tester boolean
	void setVert(int);
	
	// getter for size and hits
	int getSize() const { return this->size; }
	
	// getter for remaining hits
	int getHits() const { return this->hits; }
	
	// getter for name
	string getName() const { return this->name; }
	
	// getter for vert
	bool getVert() const { return vert; }
	
	// getter for coordinates
	int getCord(bool) const;
	
	// overloaded -- operator
	Patrol operator--(int);
	
	// print function
	void prnShip();
};

#endif /* PATROL_H */

