/* 
 * File:   Ship.cpp
 * Author: Ryan Ringer
 *
 * Purpose: Ship class specification
 */

#include <iostream>
using namespace std;

#include "shipClass.h"

Ship::Ship(){
    
}

Ship::~Ship(){
    
}

Ship::Ship(Ship & a){
    this->name = a.name;
    this->hits = a.hits;
    this->size = a.size;
    this->vert = a.vert;
    this->xCrd = a.xCrd;
    this->yCrd = a.yCrd;

}